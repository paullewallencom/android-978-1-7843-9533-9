package com.blundell.tut;

public class InvalidTemperatureException extends RuntimeException {

	public InvalidTemperatureException(String msg) {
		super(msg);
	}

}
